﻿
namespace Aula06
{
	partial class Form1
	{
		/// <summary>
		/// Variável de designer necessária.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpar os recursos que estão sendo usados.
		/// </summary>
		/// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código gerado pelo Windows Form Designer

		/// <summary>
		/// Método necessário para suporte ao Designer - não modifique 
		/// o conteúdo deste método com o editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.inícioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.filmesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.terrorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.açãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.dramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ficçãoCientificaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sériesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.dramaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.açãoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.pictureBox9 = new System.Windows.Forms.PictureBox();
			this.pictureBox8 = new System.Windows.Forms.PictureBox();
			this.pictureBox6 = new System.Windows.Forms.PictureBox();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.pictureBox7 = new System.Windows.Forms.PictureBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.menuStrip1.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.BackColor = System.Drawing.Color.MidnightBlue;
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inícioToolStripMenuItem,
            this.filmesToolStripMenuItem,
            this.sériesToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(761, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// inícioToolStripMenuItem
			// 
			this.inícioToolStripMenuItem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.inícioToolStripMenuItem.ForeColor = System.Drawing.Color.White;
			this.inícioToolStripMenuItem.Name = "inícioToolStripMenuItem";
			this.inícioToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
			this.inícioToolStripMenuItem.Text = "Início";
			// 
			// filmesToolStripMenuItem
			// 
			this.filmesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.terrorToolStripMenuItem,
            this.açãoToolStripMenuItem,
            this.dramaToolStripMenuItem,
            this.ficçãoCientificaToolStripMenuItem});
			this.filmesToolStripMenuItem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.filmesToolStripMenuItem.ForeColor = System.Drawing.Color.White;
			this.filmesToolStripMenuItem.Name = "filmesToolStripMenuItem";
			this.filmesToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
			this.filmesToolStripMenuItem.Text = "Filmes";
			// 
			// terrorToolStripMenuItem
			// 
			this.terrorToolStripMenuItem.Name = "terrorToolStripMenuItem";
			this.terrorToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
			this.terrorToolStripMenuItem.Text = "Terror";
			// 
			// açãoToolStripMenuItem
			// 
			this.açãoToolStripMenuItem.Name = "açãoToolStripMenuItem";
			this.açãoToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
			this.açãoToolStripMenuItem.Text = "Ação";
			// 
			// dramaToolStripMenuItem
			// 
			this.dramaToolStripMenuItem.Name = "dramaToolStripMenuItem";
			this.dramaToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
			this.dramaToolStripMenuItem.Text = "Drama";
			// 
			// ficçãoCientificaToolStripMenuItem
			// 
			this.ficçãoCientificaToolStripMenuItem.Name = "ficçãoCientificaToolStripMenuItem";
			this.ficçãoCientificaToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
			this.ficçãoCientificaToolStripMenuItem.Text = "Ficção Cientifica";
			// 
			// sériesToolStripMenuItem
			// 
			this.sériesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dramaToolStripMenuItem1,
            this.açãoToolStripMenuItem1});
			this.sériesToolStripMenuItem.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.sériesToolStripMenuItem.ForeColor = System.Drawing.Color.White;
			this.sériesToolStripMenuItem.Name = "sériesToolStripMenuItem";
			this.sériesToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
			this.sériesToolStripMenuItem.Text = "Séries";
			// 
			// dramaToolStripMenuItem1
			// 
			this.dramaToolStripMenuItem1.Name = "dramaToolStripMenuItem1";
			this.dramaToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
			this.dramaToolStripMenuItem1.Text = "Drama";
			// 
			// açãoToolStripMenuItem1
			// 
			this.açãoToolStripMenuItem1.Name = "açãoToolStripMenuItem1";
			this.açãoToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
			this.açãoToolStripMenuItem1.Text = "Ação";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(12, 239);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(221, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Os melhores filmes recomendados";
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
			this.panel1.Controls.Add(this.pictureBox4);
			this.panel1.Controls.Add(this.pictureBox3);
			this.panel1.Controls.Add(this.pictureBox2);
			this.panel1.Location = new System.Drawing.Point(5, 264);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(750, 144);
			this.panel1.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(4, 423);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(178, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Séries que você precisa assistir";
			// 
			// panel2
			// 
			this.panel2.AutoScroll = true;
			this.panel2.BackColor = System.Drawing.Color.MidnightBlue;
			this.panel2.Controls.Add(this.pictureBox9);
			this.panel2.Controls.Add(this.pictureBox8);
			this.panel2.Controls.Add(this.pictureBox6);
			this.panel2.Controls.Add(this.pictureBox5);
			this.panel2.Controls.Add(this.pictureBox7);
			this.panel2.Location = new System.Drawing.Point(5, 442);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(750, 144);
			this.panel2.TabIndex = 4;
			// 
			// pictureBox9
			// 
			this.pictureBox9.Image = global::Aula06.Properties.Resources.loki;
			this.pictureBox9.Location = new System.Drawing.Point(900, 12);
			this.pictureBox9.Name = "pictureBox9";
			this.pictureBox9.Size = new System.Drawing.Size(200, 100);
			this.pictureBox9.TabIndex = 4;
			this.pictureBox9.TabStop = false;
			// 
			// pictureBox8
			// 
			this.pictureBox8.Image = global::Aula06.Properties.Resources.better_call_saul;
			this.pictureBox8.Location = new System.Drawing.Point(678, 12);
			this.pictureBox8.Name = "pictureBox8";
			this.pictureBox8.Size = new System.Drawing.Size(200, 100);
			this.pictureBox8.TabIndex = 3;
			this.pictureBox8.TabStop = false;
			// 
			// pictureBox6
			// 
			this.pictureBox6.Image = global::Aula06.Properties.Resources.the_boys;
			this.pictureBox6.Location = new System.Drawing.Point(453, 12);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Size = new System.Drawing.Size(200, 100);
			this.pictureBox6.TabIndex = 2;
			this.pictureBox6.TabStop = false;
			// 
			// pictureBox5
			// 
			this.pictureBox5.Image = global::Aula06.Properties.Resources.Cyberpunk_editado;
			this.pictureBox5.Location = new System.Drawing.Point(231, 12);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(200, 100);
			this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox5.TabIndex = 1;
			this.pictureBox5.TabStop = false;
			// 
			// pictureBox7
			// 
			this.pictureBox7.Image = global::Aula06.Properties.Resources.braking_bad_editado;
			this.pictureBox7.Location = new System.Drawing.Point(10, 12);
			this.pictureBox7.Name = "pictureBox7";
			this.pictureBox7.Size = new System.Drawing.Size(200, 100);
			this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox7.TabIndex = 0;
			this.pictureBox7.TabStop = false;
			// 
			// pictureBox4
			// 
			this.pictureBox4.Image = global::Aula06.Properties.Resources.corraeditado;
			this.pictureBox4.Location = new System.Drawing.Point(529, 13);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(215, 120);
			this.pictureBox4.TabIndex = 2;
			this.pictureBox4.TabStop = false;
			// 
			// pictureBox3
			// 
			this.pictureBox3.Image = global::Aula06.Properties.Resources.clube_da_luta_editado;
			this.pictureBox3.Location = new System.Drawing.Point(270, 13);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(215, 120);
			this.pictureBox3.TabIndex = 1;
			this.pictureBox3.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = global::Aula06.Properties.Resources.Bastardos_Inglorious_editado;
			this.pictureBox2.Location = new System.Drawing.Point(7, 13);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(215, 120);
			this.pictureBox2.TabIndex = 0;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::Aula06.Properties.Resources.the_boys_banner;
			this.pictureBox1.Location = new System.Drawing.Point(5, 27);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(750, 200);
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(761, 598);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.menuStrip1);
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "Form1";
			this.Text = "Form1";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem inícioToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem filmesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem terrorToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem açãoToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem dramaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem ficçãoCientificaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sériesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem dramaToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem açãoToolStripMenuItem1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.PictureBox pictureBox9;
		private System.Windows.Forms.PictureBox pictureBox8;
		private System.Windows.Forms.PictureBox pictureBox6;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox7;
	}
}

