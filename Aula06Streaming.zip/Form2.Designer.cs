﻿
namespace Aula06
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblTitulo = new System.Windows.Forms.Label();
			this.btnAssistir = new System.Windows.Forms.Button();
			this.lblDescricao = new System.Windows.Forms.Label();
			this.imgFundo = new System.Windows.Forms.PictureBox();
			this.wvVideo = new Microsoft.Web.WebView2.WinForms.WebView2();
			((System.ComponentModel.ISupportInitialize)(this.imgFundo)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.wvVideo)).BeginInit();
			this.SuspendLayout();
			// 
			// lblTitulo
			// 
			this.lblTitulo.AutoSize = true;
			this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
			this.lblTitulo.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.ForeColor = System.Drawing.Color.White;
			this.lblTitulo.Location = new System.Drawing.Point(68, 202);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Size = new System.Drawing.Size(91, 34);
			this.lblTitulo.TabIndex = 1;
			this.lblTitulo.Text = "Título";
			// 
			// btnAssistir
			// 
			this.btnAssistir.BackColor = System.Drawing.Color.DarkSlateBlue;
			this.btnAssistir.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAssistir.ForeColor = System.Drawing.Color.White;
			this.btnAssistir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAssistir.Location = new System.Drawing.Point(74, 266);
			this.btnAssistir.Name = "btnAssistir";
			this.btnAssistir.Size = new System.Drawing.Size(122, 48);
			this.btnAssistir.TabIndex = 2;
			this.btnAssistir.Text = "Assistir";
			this.btnAssistir.UseVisualStyleBackColor = false;
			this.btnAssistir.Click += new System.EventHandler(this.btnAssistir_Click);
			// 
			// lblDescricao
			// 
			this.lblDescricao.AutoSize = true;
			this.lblDescricao.BackColor = System.Drawing.Color.Transparent;
			this.lblDescricao.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDescricao.ForeColor = System.Drawing.Color.White;
			this.lblDescricao.Location = new System.Drawing.Point(70, 353);
			this.lblDescricao.MaximumSize = new System.Drawing.Size(400, 0);
			this.lblDescricao.Name = "lblDescricao";
			this.lblDescricao.Size = new System.Drawing.Size(110, 19);
			this.lblDescricao.TabIndex = 3;
			this.lblDescricao.Text = "Descrição aqui";
			// 
			// imgFundo
			// 
			this.imgFundo.Location = new System.Drawing.Point(1, -1);
			this.imgFundo.Name = "imgFundo";
			this.imgFundo.Size = new System.Drawing.Size(801, 569);
			this.imgFundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.imgFundo.TabIndex = 0;
			this.imgFundo.TabStop = false;
			// 
			// wvVideo
			// 
			this.wvVideo.AllowExternalDrop = true;
			this.wvVideo.CreationProperties = null;
			this.wvVideo.DefaultBackgroundColor = System.Drawing.Color.White;
			this.wvVideo.Location = new System.Drawing.Point(1, -1);
			this.wvVideo.Name = "wvVideo";
			this.wvVideo.Size = new System.Drawing.Size(801, 569);
			this.wvVideo.TabIndex = 4;
			this.wvVideo.Visible = false;
			this.wvVideo.ZoomFactor = 1D;
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 567);
			this.Controls.Add(this.wvVideo);
			this.Controls.Add(this.lblDescricao);
			this.Controls.Add(this.btnAssistir);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.imgFundo);
			this.Name = "Form2";
			this.Text = "Form2";
			this.Load += new System.EventHandler(this.Form2_Load);
			((System.ComponentModel.ISupportInitialize)(this.imgFundo)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.wvVideo)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox imgFundo;
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Button btnAssistir;
		private System.Windows.Forms.Label lblDescricao;
		private Microsoft.Web.WebView2.WinForms.WebView2 wvVideo;
	}
}