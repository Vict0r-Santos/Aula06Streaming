﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula06
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void dToolStripMenuItem_Click(object sender, EventArgs e)
		{

		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void pictureBox2_Click(object sender, EventArgs e)
		{

			string titulo = "Bastardos Inglórios";
			string descricao = "Durante a Segunda Guerra Mundial, na França, judeus americanos espalham o terror entre o terceiro Reich. Ao mesmo tempo, Shosanna, uma judia que fugiu dos nazistas, planeja vingança quando um evento em seu cinema reunirá os líderes do partido.";
			string caminhoImg = "D:/Users/victor.gssilva9/Downloads/inglourious basterds.png";
			string video = "https://www.youtube.com/embed/QULkfEiz_e4";


			Form2 telaInfo = new Form2();
			telaInfo.titulo = titulo;
			telaInfo.descricao = descricao;
			telaInfo.caminhoImg = caminhoImg;
			telaInfo.video = video;
			telaInfo.Show();
		}
	}
}
